// hello, world
#include <inc/lib.h>
void
umain(int argc, char **argv)
{
    int i;
    for (i = 1; i <= 4; ++i) {
        int pid = pfork(i);
        if (pid == 0) {
            cprintf("child %x is now present but not yet yielded\n", i);
            for (int j = 0; j < 4; ++j) {
                cprintf("child %x is yielding\n", i);
                sys_yield();
            }
            break;
        }
    }
}
/*
void
umain(int argc, char **argv)
{
  cprintf("hello, world\n");
  cprintf("i am environment %08x\n", thisenv->env_id);
}
*/


