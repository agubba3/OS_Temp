#include "ns.h"

extern union Nsipc nsipcbuf;

void
output(envid_t ns_envid)
{
	binaryname = "ns_output";

	uint32_t req;

	while (1) {
		req = ipc_recv(0, &nsipcbuf, 0); //read packet from network server
		if (req == NSREQ_OUTPUT) {
			//transmit packet with device driver
			while(sys_net_transmit(nsipcbuf.pkt.jp_data, nsipcbuf.pkt.jp_len) < 0) sys_yield();
		}
	}

}
