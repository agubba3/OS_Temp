#include <kern/e1000.h>

struct e1000_tx_desc tx_desc_buf[TXRING_LEN] __attribute__ ((aligned (PGSIZE)));
struct e1000_data tx_data_buf[TXRING_LEN] __attribute__ ((aligned (PGSIZE)));

struct e1000_rx_desc rx_desc_buf[RXRING_LEN] __attribute__ ((aligned (PGSIZE)));
struct e1000_data rx_data_buf[RXRING_LEN] __attribute__ ((aligned (PGSIZE)));

// LAB 6: Your driver code here

static void init_descriptors() {
	for (int i = 0; i < TXRING_LEN; ++i) {
		tx_desc_buf[i].buffer_addr = PADDR(&tx_data_buf[i]);
		tx_desc_buf[i].upper.fields.status = E1000_TXD_STAT_DD;
	}
	for (int i = 0; i < RXRING_LEN; i++) {
		rx_desc_buf[i].buffer_addr = PADDR(&rx_data_buf[i]);
	}
}

static void e1000_board_init() {
	//transmit:
	e1000[E1000_TDBAL] = PADDR(tx_desc_buf);
	e1000[E1000_TDH] = 0x0;
	e1000[E1000_TDT] = 0x0;
	e1000[E1000_TDBAH] = 0x0;
	e1000[E1000_TDLEN] = TXRING_LEN * sizeof(struct e1000_tx_desc);
	e1000[E1000_TCTL] = VALUEATMASK(1, E1000_TCTL_EN) | VALUEATMASK(1, E1000_TCTL_PSP) | VALUEATMASK(0x10, E1000_TCTL_CT) | VALUEATMASK(0x40, E1000_TCTL_COLD);
	e1000[E1000_TIPG] = VALUEATMASK(10, E1000_TIPG_IPGT) | VALUEATMASK(8, E1000_TIPG_IPGR1) | VALUEATMASK(6, E1000_TIPG_IPGR2);
	//recv:
	e1000[E1000_RAL] = 0x12005452;
	e1000[E1000_RDBAL] = PADDR(rx_desc_buf);
	e1000[E1000_RDBAH] = 0x0;
	e1000[E1000_RDH] = 0x0;
	e1000[E1000_RAH] = 0x00005634 | E1000_RAH_AV;
	e1000[E1000_RDLEN] = RXRING_LEN * sizeof(struct e1000_rx_desc);
	e1000[E1000_RDT] = RXRING_LEN;
	e1000[E1000_RCTL] = E1000_RCTL_EN | E1000_RCTL_SECRC | E1000_RCTL_SZ_4096 | E1000_RCTL_BAM | E1000_RCTL_BSEX | E1000_RCTL_MO_0 | E1000_RCTL_RDMTS_HALF | E1000_RCTL_LBM_NO | !E1000_RCTL_LPE;
}

int e1000_attach(struct pci_func *pci) {
        pci_func_enable(pci);
        init_descriptors(); //initialize the descriptors
        //create virtual memory mappings
        e1000 = mmio_map_region(pci->reg_base[0], pci->reg_size[0]);
        assert(e1000[E1000_STATUS] == 0x80080783);
        e1000_board_init(); //initialize hardware
        return 0;
}

int e1000_transmit(uint8_t * address, size_t pl) {
	uint32_t tailOfTQ = e1000[E1000_TDT];
	struct e1000_tx_desc * tail_desc = &tx_desc_buf[tailOfTQ];
	if (tail_desc->upper.fields.status != E1000_TXD_STAT_DD) return -1; //its all full
	pl = pl > DATA_SIZE ? DATA_SIZE : pl;
	memmove(&tx_data_buf[tailOfTQ], address, pl);
	tail_desc->upper.fields.status = 0;
	tail_desc->lower.flags.length = pl;
	tail_desc->lower.data |= E1000_TXD_CMD_RS | E1000_TXD_CMD_EOP;
	e1000[E1000_TDT] = (1 + tailOfTQ) % TXRING_LEN; //update
	return 0;
}

int e1000_recv(uint8_t * packet) {
	static uint32_t ta = 0;
	uint32_t t = ta;
	struct e1000_rx_desc * ctail = &rx_desc_buf[t];
	if (!(ctail->status & E1000_RXD_STAT_DD)) return -1; //dd bit isnt set so queue is full/empty
	memmove(packet, &rx_data_buf[t], ctail->length);
	ctail->status = 0;
	e1000[E1000_RDT] = t;
	ta = (1 + t) % RXRING_LEN;
	return ctail->length;
}	
