#ifndef JOS_KERN_E1000_H
#define JOS_KERN_E1000_H

#include <kern/pci.h>
#include <kern/pmap.h>
#include <inc/string.h>

#define E1000_DEV_ID_82540EM 0x100E
#define E1000_STATUS   0x00008/4  /* Device Status - RO */
#define VALUEATMASK(value, mask) value * ((mask) & ~((mask) << 1))

//Buffer sizes
#define E1000_RCTL_SZ_16384       0x00010000    
#define E1000_RCTL_SZ_8192        0x00020000    
#define E1000_RCTL_SZ_4096        0x00030000    

#define E1000_RCTL_VFE            0x00040000   
#define E1000_RCTL_CFIEN          0x00080000    
#define E1000_RCTL_CFI            0x00100000    
#define E1000_RCTL_DPF            0x00400000    
#define E1000_RCTL_PMCF           0x00800000    
#define E1000_RCTL_BSEX           0x02000000    
#define E1000_RCTL_SECRC          0x04000000    
#define E1000_RCTL_FLXBUF_MASK    0x78000000    
#define E1000_RCTL_FLXBUF_SHIFT   27

//FOR TRANSMITTING
#define E1000_TCTL_RST    0x00000001   
#define E1000_TCTL_EN     0x00000002   
#define E1000_TCTL_BCE    0x00000004   
#define E1000_TCTL_PSP    0x00000008    
#define E1000_TCTL_CT     0x00000ff0   
#define E1000_TCTL_COLD   0x003ff000  
#define E1000_TCTL_SWXOFF 0x00400000 
#define E1000_TCTL_PBE    0x00800000
#define E1000_TCTL_RTLC   0x01000000    
#define E1000_TCTL_NRTU   0x02000000   
#define E1000_TCTL_MULR   0x10000000   

#define E1000_RCTL_RST            0x00000001   
#define E1000_RCTL_EN             0x00000002    
#define E1000_RCTL_SBP            0x00000004    
#define E1000_RCTL_UPE            0x00000008    
#define E1000_RCTL_MPE            0x00000010    
#define E1000_RCTL_LPE            0x00000020    
#define E1000_RCTL_LBM_NO         0x00000000   
#define E1000_RCTL_LBM_MAC        0x00000040  

#define E1000_RCTL_MO_SHIFT       12            
#define E1000_RCTL_MO_0           0x00000000    
#define E1000_RCTL_MO_1           0x00001000    
#define E1000_RCTL_MO_2           0x00002000    
#define E1000_RCTL_MO_3           0x00003000    
#define E1000_RCTL_MDR            0x00004000    
#define E1000_RCTL_BAM            0x00008000    

#define E1000_RCTL_SZ_2048        0x00000000    
#define E1000_RCTL_SZ_1024        0x00010000    
#define E1000_RCTL_SZ_512         0x00020000    
#define E1000_RCTL_SZ_256         0x00030000    

#define E1000_RCTL_LBM_SLP        0x00000080   
#define E1000_RCTL_LBM_TCVR       0x000000C0   
#define E1000_RCTL_DTYP_MASK      0x00000C00  
#define E1000_RCTL_DTYP_PS        0x00000400  
#define E1000_RCTL_RDMTS_HALF     0x00000000   
#define E1000_RCTL_RDMTS_QUAT     0x00000100   
#define E1000_RCTL_RDMTS_EIGTH    0x00000200   

//Packet data descriptors
#define E1000_TXD_DTYP_D     0x00100000 
#define E1000_TXD_DTYP_C     0x00000000 
#define E1000_TXD_POPTS_IXSM 0x01       
#define E1000_TXD_POPTS_TXSM 0x02       
#define E1000_TXD_CMD_EOP    0x01000000 
#define E1000_TXD_CMD_IFCS   0x02000000 
#define E1000_TXD_CMD_IC     0x04000000 
#define E1000_TXD_CMD_RS     0x08000000 
#define E1000_TXD_CMD_RPS    0x10000000 
#define E1000_TXD_CMD_DEXT   0x20000000 
#define E1000_TXD_CMD_VLE    0x40000000 
#define E1000_TXD_CMD_IDE    0x80000000 
#define E1000_TXD_STAT_DD    0x00000001 
#define E1000_TXD_STAT_EC    0x00000002 
#define E1000_TXD_STAT_LC    0x00000004 
#define E1000_TXD_STAT_TU    0x00000008 
#define E1000_TXD_CMD_TCP    0x01000000 
#define E1000_TXD_CMD_IP     0x02000000 

//tcp/io packet info
#define E1000_TXD_CMD_TSE    0x04000000 
#define E1000_TXD_STAT_TC    0x00000004 

#define E1000_RXD_STAT_DD       0x01    
#define E1000_RXD_STAT_EOP      0x02    
#define E1000_RXD_STAT_IXSM     0x04    
#define E1000_RXD_STAT_VP       0x08    
#define E1000_RXD_STAT_UDPCS    0x10    
#define E1000_RXD_STAT_TCPCS    0x20    
#define E1000_RXD_STAT_IPCS     0x40   
#define E1000_RXD_STAT_PIF      0x80   
#define E1000_RXD_STAT_IPIDV    0x200  
#define E1000_RXD_STAT_UDPV     0x400   
#define E1000_RXD_STAT_ACK      0x8000  
#define E1000_RXD_ERR_CE        0x01    
#define E1000_RXD_ERR_SE        0x02    
#define E1000_RXD_ERR_SEQ       0x04    
#define E1000_RXD_ERR_CXE       0x10    
#define E1000_RXD_ERR_TCPE      0x20    
#define E1000_RXD_ERR_IPE       0x40    
#define E1000_RXD_ERR_RXE       0x80    
#define E1000_RXD_SPC_VLAN_MASK 0x0FFF  
#define E1000_RXD_SPC_PRI_MASK  0xE000  
#define E1000_RXD_SPC_PRI_SHIFT 13
#define E1000_RXD_SPC_CFI_MASK  0x1000  /* CFI is bit 12 */
#define E1000_RXD_SPC_CFI_SHIFT 12

#define E1000_RA       0x05400 / 4  
#define E1000_RAL      0x05400 / 4  
#define E1000_RAH      0x05404 / 4  
#define E1000_RDBAL    0x02800 / 4  
#define E1000_RDBAH    0x02804 / 4  
#define E1000_RDLEN    0x02808 / 4  
#define E1000_RDH      0x02810 / 4  
#define E1000_RDT      0x02818 / 4 

#define E1000_EERD     0x00014 / 4  
#define E1000_TCTL     0x00400 / 4  
#define E1000_TIPG     0x00410 / 4  
#define E1000_TDBAL    0x03800 / 4  
#define E1000_TDBAH    0x03804 / 4  
#define E1000_TDLEN    0x03808 / 4  
#define E1000_TDH      0x03810 / 4  
#define E1000_TDT      0x03818 / 4  
#define E1000_RCTL     0x00100 / 4  

#define E1000_TIPG_IPGT      0x000003FF
#define E1000_TIPG_IPGR1     0x000FFA00
#define E1000_TIPG_IPGR2     0x3FF00000

#define E1000_RAH_AV  0x80000000        /* Receive descriptor valid */

#define TXRING_LEN 64
#define RXRING_LEN 128
#define DATA_SIZE 4096

struct e1000_data {
    uint8_t data[DATA_SIZE];
};

//transmit descriptor
struct e1000_tx_desc {
    uint64_t buffer_addr;      
    union {
        uint32_t data;
        struct {
            uint16_t length;   
            uint8_t cso;       
            uint8_t cmd;     
        } flags;
    } lower;
    union {
        uint32_t data;
        struct {
            uint8_t status;    
            uint8_t css;       
            uint16_t special;
        } fields;
    } upper;
};

//recv descriptor
struct e1000_rx_desc {
    uint64_t buffer_addr; 
    uint16_t length;    
    uint16_t csum;      
    uint8_t status;     
    uint8_t errors;     
    uint16_t special;
};

volatile uint32_t * e1000;

int e1000_attach(struct pci_func *pci);
int e1000_transmit(uint8_t * address, size_t pl);
int e1000_recv(uint8_t * packet);

#endif	// JOS_KERN_E1000_H
