// hello, world
#include <inc/lib.h>

void
umain(int argc, char **argv)
{



	cprintf("hello, world\n");
	cprintf("i am environment %08x\n", thisenv->env_id);


  char s[2][50] = {
    "/echo",
    "SOME INPUT, IDK"
  };
  char *argv2[3] = {s[0], s[1], 0};

  cprintf("HELLO, world\n");
  cprintf("This is the environment %08x\n", thisenv->env_id);
//  exec("/echo", (const char**) argv2);
}
