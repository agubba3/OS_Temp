#include <inc/lib.h>
#include <inc/elf.h>


// This is taking in command line params which must be null terminated!
int
execl(const char *program, const char *arg0, ...)
{

  int argc = 0;
  va_list addrlist;

//go until we hit null

  va_start(addrlist, arg0);
  while (va_arg(addrlist, void *) != NULL) {
    argc++;
  }
  va_end(addrlist);

  const char *argv[argc+2];
  argv[0] = arg0;
  argv[argc+1] = NULL;

  va_start(addrlist, arg0);
  unsigned i;
  for (i = 0; i < argc; i++)
    argv[i+1] = va_arg(addrlist, const char *);
  va_end(addrlist);
  return exec(program, argv);
}


// Execute a program from the image loaded
int
exec(const char *program, const char **argv)
{

  unsigned char elf_buf[512];

  int perm;
  intptr_t temp = CODETEMP;
  struct Stat statbuf;
  int fd, i, openout, n;


  struct Elf *fileELF;

  if ((openout = open(program, O_RDONLY)) < 0)
    return openout;

  fd = openout;

  if ((openout = fstat(fd, &statbuf)) < 0) {
    return -E_INVAL;
  }

  for (i = temp; i < ROUNDUP(temp + statbuf.st_size, PGSIZE); i += PGSIZE) {
     if ((openout = sys_page_alloc(0, (void*)i, PTE_P | PTE_U | PTE_W)) < 0) {
	sys_env_destroy(0);
	close(fd);
	return openout;
	}
     n = readn(fd, (void*) i, PGSIZE);
  }

  fileELF = (struct Elf*)temp;
  if (fileELF->e_magic != ELF_MAGIC) {
    close(fd);
    return -E_NOT_EXEC;
  }

  if ((openout = sys_exec((void*)temp, argv)) < 0) { 
	     sys_env_destroy(0);
	close(fd);
     return openout;
  }

  close(fd);
  fd = -1;
  return 0;
}


